/** Auto-generated to unblock Netlify build. */
module.exports = {

  "typescript": {
    "ignoreBuildErrors": true
  },
  "eslint": {
    "ignoreDuringBuilds": true
  }
};
