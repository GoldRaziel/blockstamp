export default function Head() {
  return <meta name="robots" content="noindex,nofollow,noarchive" />;
}
