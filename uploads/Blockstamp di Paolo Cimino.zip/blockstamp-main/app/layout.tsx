import Nav from "./components/Nav";
// app/layout.tsx
import "./globals.css";
import type { Metadata } from "next";
import Image from "next/image";
import DisableContextMenu from "./components/DisableContextMenu";

export const metadata: Metadata = {
  title: "BLOCKSTAMP — Proof of Existence",
  description: "Hash locale, prova di esistenza su blockchain. Privacy by design.",
  openGraph: {
    title: "BLOCKSTAMP — Proof of Existence",
    description: "Hash locale e timestamp pubblico su blockchain.",
    type: "website",
  },
  icons: {
    icon: "/favicon.ico",
    shortcut: "/favicon-32x32.png",
    apple: "/favicon-180x180.png",
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  const year = new Date().getFullYear();
  return (
    <html lang="it">
      <body className="select-none select-none">
          <DisableContextMenu />
        <header className="border-b border-white/10">
          <div className="container mx-auto px-4 py-3 flex flex-col md:flex-row md:items-center md:justify-between gap-2">
            <div className="flex justify-start">
              <a href="/" className="flex items-center gap-3" aria-label="Vai alla Home">
                <Image
                  src="/logo.png"
                  alt="BLOCKSTAMP logo"
                  width={1000}
                  height={500}
                  priority
                  sizes="(max-width: 768px) 200px, 400px"
                  className="h-auto max-h-14 md:max-h-20 w-auto origin-left md:scale-100 scale-[1.15]"
                />
              </a>
            </div>
            <Nav />
          </div>
</header>

        <main className="container mx-auto px-4 py-10">{children}</main>

        <div id="contact"></div>
<footer id="contatti" className="border-t border-white/10 mt-16">
          <div className="container mx-auto px-4 py-6 text-sm opacity-80 flex items-center justify-center gap-3 flex-wrap text-center">
            <span>© {year} BLOCKSTAMP — Proof of Existence</span>
            <span className="hidden sm:inline">•</span>
            <a
              href="mailto:blockstamp.protection@gmail.com"
              className="hover:text-sky-400 transition"
            >
              blockstamp.protection@gmail.com
           </a>

    {/* Forza l'andata a capo in flex */}
    <span className="basis-full w-full" />
    
    <span>
      Falcon Prime Solutions FZE • Business Center • Sharjah, UAE
    </span>
  </div>
</footer>
      </body>
    </html>
  );
}
